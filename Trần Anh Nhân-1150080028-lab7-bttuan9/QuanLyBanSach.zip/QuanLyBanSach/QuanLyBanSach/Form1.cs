﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QuanLyBanSach
{
    public partial class Form1 : Form
    {
        private readonly string strCon =
     @"Data Source=ehe\sqlexpress01;Initial Catalog=QuanLyBanSach;Integrated Security=True";

        private SqlConnection sqlCon;
        private SqlDataAdapter adapter;
        private DataSet ds;

        public Form1()
        {
            InitializeComponent();
            btnHienThi.Click += BtnHienThi_Click;
        }

        private void OpenConn() { if (sqlCon == null) sqlCon = new SqlConnection(strCon); if (sqlCon.State == ConnectionState.Closed) sqlCon.Open(); }
        private void CloseConn() { if (sqlCon != null && sqlCon.State == ConnectionState.Open) sqlCon.Close(); }

        private void BtnHienThi_Click(object sender, EventArgs e)
        {
            try
            {
                OpenConn();
                adapter = new SqlDataAdapter("SELECT MaXB, TenXB, DiaChi FROM dbo.NhaXuatBan", sqlCon);
                ds = new DataSet();
                adapter.Fill(ds, "NhaXuatBan");
                dgvNxb.DataSource = ds.Tables["NhaXuatBan"];
            }
            catch (Exception ex) { MessageBox.Show("Lỗi hiển thị: " + ex.Message); }
            finally { CloseConn(); }
        }
    }
}
