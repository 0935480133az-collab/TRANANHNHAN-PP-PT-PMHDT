﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QuanLyBanSach
{
    public partial class Form2 : Form
    {
        private readonly string strCon =
      @"Data Source=ehe\sqlexpress01;Initial Catalog=QuanLyBanSach;Integrated Security=True";

        private SqlConnection sqlCon;
        private SqlDataAdapter adapter;
        private SqlCommandBuilder builder;
        private DataSet ds;

        public Form2()
        {
            InitializeComponent();
            this.Load += Form2_Load;
            btnThem.Click += BtnThem_Click;
        }

        private void OpenConn() { if (sqlCon == null) sqlCon = new SqlConnection(strCon); if (sqlCon.State == ConnectionState.Closed) sqlCon.Open(); }
        private void CloseConn() { if (sqlCon != null && sqlCon.State == ConnectionState.Open) sqlCon.Close(); }

        private void Form2_Load(object sender, EventArgs e) => LoadData();

        private void LoadData()
        {
            OpenConn();
            adapter = new SqlDataAdapter("SELECT MaXB, TenXB, DiaChi FROM dbo.NhaXuatBan", sqlCon);
            builder = new SqlCommandBuilder(adapter);      // tự sinh Insert/Update/Delete
            ds = new DataSet();
            adapter.Fill(ds, "NhaXuatBan");

            var tbl = ds.Tables["NhaXuatBan"];
            if (tbl.PrimaryKey == null || tbl.PrimaryKey.Length == 0)
                tbl.PrimaryKey = new DataColumn[] { tbl.Columns["MaXB"] };

            dgvNxb.DataSource = tbl;
            CloseConn();
        }

        private void BtnThem_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtMaXB.Text) || string.IsNullOrWhiteSpace(txtTenXB.Text))
            { MessageBox.Show("MaXB và TenXB bắt buộc!"); return; }

            try
            {
                DataRow row = ds.Tables["NhaXuatBan"].NewRow();
                row["MaXB"] = txtMaXB.Text.Trim();
                row["TenXB"] = txtTenXB.Text.Trim();
                row["DiaChi"] = string.IsNullOrWhiteSpace(txtDiaChi.Text) ? (object)DBNull.Value : txtDiaChi.Text.Trim();

                ds.Tables["NhaXuatBan"].Rows.Add(row);
                int kq = adapter.Update(ds.Tables["NhaXuatBan"]);
                if (kq > 0) { MessageBox.Show("Thêm thành công!"); LoadData(); }
                else MessageBox.Show("Thêm không thành công!");
            }
            catch (Exception ex) { MessageBox.Show("Lỗi thêm: " + ex.Message); }
        }
    }
}
