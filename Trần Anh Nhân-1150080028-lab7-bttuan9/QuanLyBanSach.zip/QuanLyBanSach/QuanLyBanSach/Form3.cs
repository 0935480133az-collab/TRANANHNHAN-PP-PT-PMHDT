﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QuanLyBanSach
{
    public partial class Form3 : Form
    {
        private readonly string strCon =
     @"Data Source=ehe\sqlexpress01;Initial Catalog=QuanLyBanSach;Integrated Security=True";

        private SqlConnection sqlCon;
        private SqlDataAdapter adapter;
        private SqlCommandBuilder builder;
        private DataSet ds;
        private BindingSource bs;

        public Form3()
        {
            InitializeComponent();
            this.Load += Form3_Load;
            dgvNxb.CellClick += (s, e) => { /* binding tự đồng bộ textbox */ };
            btnSua.Click += BtnSua_Click;
        }

        private void OpenConn() { if (sqlCon == null) sqlCon = new SqlConnection(strCon); if (sqlCon.State == ConnectionState.Closed) sqlCon.Open(); }
        private void CloseConn() { if (sqlCon != null && sqlCon.State == ConnectionState.Open) sqlCon.Close(); }

        private void Form3_Load(object sender, EventArgs e) => LoadData();

        private void LoadData()
        {
            OpenConn();
            adapter = new SqlDataAdapter("SELECT MaXB, TenXB, DiaChi FROM dbo.NhaXuatBan", sqlCon);
            builder = new SqlCommandBuilder(adapter);
            ds = new DataSet();
            adapter.Fill(ds, "NhaXuatBan");

            var tbl = ds.Tables["NhaXuatBan"];
            if (tbl.PrimaryKey == null || tbl.PrimaryKey.Length == 0)
                tbl.PrimaryKey = new DataColumn[] { tbl.Columns["MaXB"] };

            bs = new BindingSource { DataSource = tbl };
            dgvNxb.DataSource = bs;

            // bind textbox
            txtMaXB.DataBindings.Clear();
            txtTenXB.DataBindings.Clear();
            txtDiaChi.DataBindings.Clear();
            txtMaXB.DataBindings.Add("Text", bs, "MaXB", true, DataSourceUpdateMode.Never);
            txtTenXB.DataBindings.Add("Text", bs, "TenXB", true, DataSourceUpdateMode.Never);
            txtDiaChi.DataBindings.Add("Text", bs, "DiaChi", true, DataSourceUpdateMode.Never);

            CloseConn();
        }

        private void BtnSua_Click(object sender, EventArgs e)
        {
            if (bs == null || bs.Current == null) { MessageBox.Show("Chọn 1 dòng để sửa!"); return; }
            try
            {
                string ma = txtMaXB.Text.Trim();
                DataRow row = ds.Tables["NhaXuatBan"].Rows.Find(ma);
                if (row == null) { MessageBox.Show("Không tìm thấy bản ghi!"); return; }

                row.BeginEdit();
                row["TenXB"] = txtTenXB.Text.Trim();
                row["DiaChi"] = string.IsNullOrWhiteSpace(txtDiaChi.Text) ? (object)DBNull.Value : txtDiaChi.Text.Trim();
                row.EndEdit();

                int kq = adapter.Update(ds.Tables["NhaXuatBan"]);
                if (kq > 0) { MessageBox.Show("Sửa thành công!"); LoadData(); }
                else MessageBox.Show("Sửa không thành công!");
            }
            catch (Exception ex) { MessageBox.Show("Lỗi sửa: " + ex.Message); }
        }
    }
}
