﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QuanLyBanSach
{
    internal static class Program
    {
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            // Mở 4 form cùng lúc
            Form1 f1 = new Form1();
            Form2 f2 = new Form2();
            Form3 f3 = new Form3();
            Form4 f4 = new Form4();

            // Hiển thị 3 form phụ không chặn chương trình
            f1.Show();
            f2.Show();
            f3.Show();
            f4.Show();

            // Giữ app sống theo form đầu tiên
            Application.Run();
        }
    }
}
