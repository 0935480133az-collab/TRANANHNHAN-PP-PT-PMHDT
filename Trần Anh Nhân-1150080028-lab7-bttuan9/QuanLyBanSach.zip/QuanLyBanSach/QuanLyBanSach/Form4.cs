﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QuanLyBanSach
{
    public partial class Form4 : Form
    {
        private readonly string strCon =
    @"Data Source=ehe\sqlexpress01;Initial Catalog=QuanLyBanSach;Integrated Security=True";

        private SqlConnection sqlCon;
        private SqlDataAdapter adapter;
        private SqlCommandBuilder builder;
        private DataSet ds;
        private BindingSource bs;

        public Form4()
        {
            InitializeComponent();
            this.Load += Form4_Load;
            btnXoa.Click += BtnXoa_Click;
        }

        private void OpenConn() { if (sqlCon == null) sqlCon = new SqlConnection(strCon); if (sqlCon.State == ConnectionState.Closed) sqlCon.Open(); }
        private void CloseConn() { if (sqlCon != null && sqlCon.State == ConnectionState.Open) sqlCon.Close(); }

        private void Form4_Load(object sender, EventArgs e) => LoadData();

        private void LoadData()
        {
            OpenConn();
            adapter = new SqlDataAdapter("SELECT MaXB, TenXB, DiaChi FROM dbo.NhaXuatBan", sqlCon);
            builder = new SqlCommandBuilder(adapter);
            ds = new DataSet();
            adapter.Fill(ds, "NhaXuatBan");

            var tbl = ds.Tables["NhaXuatBan"];
            if (tbl.PrimaryKey == null || tbl.PrimaryKey.Length == 0)
                tbl.PrimaryKey = new DataColumn[] { tbl.Columns["MaXB"] };

            bs = new BindingSource { DataSource = tbl };
            dgvNxb.DataSource = bs;
            CloseConn();
        }

        private void BtnXoa_Click(object sender, EventArgs e)
        {
            if (bs == null || bs.Current == null) { MessageBox.Show("Chọn 1 dòng để xóa!"); return; }

            var confirm = MessageBox.Show("Bạn có chắc muốn xóa bản ghi này?", "Cảnh báo",
                                          MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
            if (confirm == DialogResult.No) return;

            try
            {
                string ma = ((DataRowView)bs.Current)["MaXB"].ToString();
                DataRow row = ds.Tables["NhaXuatBan"].Rows.Find(ma);
                if (row != null) row.Delete();

                int kq = adapter.Update(ds.Tables["NhaXuatBan"]);
                if (kq > 0) { MessageBox.Show("Xóa thành công!"); LoadData(); }
                else MessageBox.Show("Xóa không thành công!");
            }
            catch (Exception ex) { MessageBox.Show("Lỗi xóa: " + ex.Message); }
        }
    }
}
